# crt
A shell that does not need to enter a password for quick login to a remote linux machine
